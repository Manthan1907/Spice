package com.rizzretro.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
